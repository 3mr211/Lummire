const fs = require("fs");

module.exports = (client) => {
  const events = fs.readdirSync("./events").filter(f => f.endsWith(".js"));
  for (const event of events) {
    const evt = require(`../events/${event}`);
    client.on(evt.name, (...args) => evt.execute(...args, client));
  }
};
