const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("روليت")
    .setDescription("لعبة روليت عربية"),
  async execute(interaction) {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("join").setLabel("دخول").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId("leave").setLabel("خروج").setStyle(ButtonStyle.Danger)
    );
    await interaction.reply({ content: "🎰 روليت", components: [row] });
  }
};
