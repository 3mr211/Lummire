module.exports = {
  name: "interactionCreate",
  async execute(interaction, client) {
    if (!interaction.isChatInputCommand()) return;
    const command = client.commands.get(interaction.commandName);
    if (!command) return;
    try {
      await command.execute(interaction);
    } catch (e) {
      console.error(e);
      interaction.reply({ content: "❌ حصل خطأ", ephemeral: true });
    }
  }
};
